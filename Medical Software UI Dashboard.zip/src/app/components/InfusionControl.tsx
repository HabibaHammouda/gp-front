import { useEffect, useState } from 'react';
import { Syringe, TrendingUp, TrendingDown, Minus } from 'lucide-react';

export function InfusionControl() {
  const [infusionRate, setInfusionRate] = useState(8.5);
  const [targetRate, setTargetRate] = useState(8.5);
  const [trend, setTrend] = useState<'up' | 'down' | 'stable'>('stable');

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate controller adjustments
      setInfusionRate(prev => {
        const adjustment = (targetRate - prev) * 0.1 + (Math.random() - 0.5) * 0.2;
        const newRate = Math.max(0, Math.min(20, prev + adjustment));
        
        // Determine trend
        if (newRate > prev + 0.05) setTrend('up');
        else if (newRate < prev - 0.05) setTrend('down');
        else setTrend('stable');
        
        return newRate;
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [targetRate]);

  const handleAdjust = (delta: number) => {
    setTargetRate(prev => Math.max(0, Math.min(20, prev + delta)));
  };

  const getTrendIcon = () => {
    if (trend === 'up') return <TrendingUp size={16} className="text-orange-500" />;
    if (trend === 'down') return <TrendingDown size={16} className="text-blue-500" />;
    return <Minus size={16} className="text-slate-400" />;
  };

  const getTrendColor = () => {
    if (trend === 'up') return 'border-orange-200 bg-orange-50';
    if (trend === 'down') return 'border-blue-200 bg-blue-50';
    return 'border-slate-200 bg-slate-50';
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200 h-full">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/30">
          <Syringe size={20} className="text-white" />
        </div>
        <div>
          <h3 className="text-slate-900">Norepinephrine</h3>
          <p className="text-sm text-slate-500">Infusion Control</p>
        </div>
      </div>

      {/* Current Rate Display */}
      <div className={`rounded-xl p-4 mb-6 border-2 transition-colors ${getTrendColor()}`}>
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-slate-600">Current Rate</span>
          {getTrendIcon()}
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-slate-900 text-4xl tabular-nums">{infusionRate.toFixed(1)}</span>
          <span className="text-slate-500">μg/min</span>
        </div>
      </div>

      {/* Manual Controls */}
      <div className="space-y-4 mb-6">
        <label className="text-sm text-slate-600">Manual Adjustment</label>
        <div className="flex gap-2">
          <button
            onClick={() => handleAdjust(-0.5)}
            className="flex-1 px-4 py-3 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
          >
            <span className="text-slate-700">-0.5</span>
          </button>
          <button
            onClick={() => handleAdjust(0.5)}
            className="flex-1 px-4 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl transition-colors"
          >
            <span>+0.5</span>
          </button>
        </div>
        <button
          onClick={() => handleAdjust(-1)}
          className="w-full px-4 py-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl transition-colors text-sm"
        >
          Emergency -1.0
        </button>
      </div>

      {/* Infusion Stats */}
      <div className="space-y-3 pt-4 border-t border-slate-200">
        <div className="flex justify-between text-sm">
          <span className="text-slate-500">Target Rate</span>
          <span className="text-slate-900 tabular-nums">{targetRate.toFixed(1)} μg/min</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-slate-500">Total Delivered</span>
          <span className="text-slate-900 tabular-nums">142.3 mg</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-slate-500">Duration</span>
          <span className="text-slate-900">2h 45m</span>
        </div>
      </div>

      {/* Status Indicator */}
      <div className="mt-6 px-3 py-2 bg-green-50 border border-green-200 rounded-lg">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-xs text-green-700">Controller Active</span>
        </div>
      </div>
    </div>
  );
}
