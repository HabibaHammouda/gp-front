import { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Area, AreaChart } from 'recharts';
import { Clock, Download } from 'lucide-react';

export function MAPTrends() {
  const [timeRange, setTimeRange] = useState<'1h' | '6h' | '12h' | '24h'>('6h');
  const [trendData, setTrendData] = useState<Array<{ time: string; map: number; target: number; systolic: number; diastolic: number }>>([]);

  useEffect(() => {
    // Generate historical trend data
    const now = new Date();
    const dataPoints = timeRange === '1h' ? 60 : timeRange === '6h' ? 72 : timeRange === '12h' ? 144 : 288;
    const intervalMinutes = timeRange === '1h' ? 1 : timeRange === '6h' ? 5 : timeRange === '12h' ? 5 : 5;

    const data = Array.from({ length: dataPoints }, (_, i) => {
      const time = new Date(now.getTime() - (dataPoints - i) * intervalMinutes * 60000);
      const baseMAP = 85 + Math.sin(i / 10) * 8 + (Math.random() - 0.5) * 4;
      
      return {
        time: time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
        map: Math.round(baseMAP),
        target: 85,
        systolic: Math.round(baseMAP * 1.35 + 20),
        diastolic: Math.round(baseMAP * 0.75 - 5),
      };
    });

    setTrendData(data);
  }, [timeRange]);

  return (
    <div className="space-y-6">
      {/* Header with controls */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-xl flex items-center justify-center">
              <Clock size={20} className="text-white" />
            </div>
            <div>
              <h3 className="text-slate-900">MAP Trends Analysis</h3>
              <p className="text-sm text-slate-500">Historical hemodynamic data</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex bg-slate-100 rounded-xl p-1">
              {(['1h', '6h', '12h', '24h'] as const).map((range) => (
                <button
                  key={range}
                  onClick={() => setTimeRange(range)}
                  className={`px-4 py-2 rounded-lg transition-all ${
                    timeRange === range
                      ? 'bg-white text-blue-600 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {range}
                </button>
              ))}
            </div>
            <button className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-xl flex items-center gap-2 transition-colors">
              <Download size={16} />
              <span>Export</span>
            </button>
          </div>
        </div>
      </div>

      {/* MAP Trend Chart */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200">
        <h4 className="text-slate-900 mb-4">Mean Arterial Pressure Over Time</h4>
        <div className="h-96 bg-gradient-to-b from-slate-50 to-white rounded-xl border border-slate-200 p-4">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="mapGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="time" 
                stroke="#64748b"
                tick={{ fill: '#64748b', fontSize: 11 }}
                interval={Math.floor(trendData.length / 12)}
              />
              <YAxis 
                domain={[60, 120]}
                stroke="#64748b"
                tick={{ fill: '#64748b', fontSize: 12 }}
                label={{ value: 'mmHg', angle: -90, position: 'insideLeft', fill: '#64748b' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e2e8f0', 
                  borderRadius: '0.75rem',
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
                }}
              />
              <Legend />
              <Area 
                type="monotone" 
                dataKey="map" 
                stroke="#3b82f6" 
                strokeWidth={2.5}
                fill="url(#mapGradient)"
                name="MAP"
              />
              <Line 
                type="monotone" 
                dataKey="target" 
                stroke="#10b981" 
                strokeDasharray="5 5"
                strokeWidth={2}
                dot={false}
                name="Target MAP"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Blood Pressure Range Chart */}
      <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200">
        <h4 className="text-slate-900 mb-4">Systolic / Diastolic Trends</h4>
        <div className="h-80 bg-gradient-to-b from-slate-50 to-white rounded-xl border border-slate-200 p-4">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis 
                dataKey="time" 
                stroke="#64748b"
                tick={{ fill: '#64748b', fontSize: 11 }}
                interval={Math.floor(trendData.length / 12)}
              />
              <YAxis 
                domain={[40, 160]}
                stroke="#64748b"
                tick={{ fill: '#64748b', fontSize: 12 }}
                label={{ value: 'mmHg', angle: -90, position: 'insideLeft', fill: '#64748b' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'white', 
                  border: '1px solid #e2e8f0', 
                  borderRadius: '0.75rem',
                  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="systolic" 
                stroke="#ef4444" 
                strokeWidth={2}
                dot={false}
                name="Systolic"
              />
              <Line 
                type="monotone" 
                dataKey="diastolic" 
                stroke="#8b5cf6" 
                strokeWidth={2}
                dot={false}
                name="Diastolic"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-4 gap-6">
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200">
          <p className="text-sm text-slate-500 mb-2">Average MAP</p>
          <p className="text-slate-900 text-3xl">87 mmHg</p>
          <p className="text-sm text-green-600 mt-2">↑ 3.2% from previous</p>
        </div>
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200">
          <p className="text-sm text-slate-500 mb-2">Time in Target</p>
          <p className="text-slate-900 text-3xl">94.3%</p>
          <p className="text-sm text-green-600 mt-2">Excellent control</p>
        </div>
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200">
          <p className="text-sm text-slate-500 mb-2">MAP Variability</p>
          <p className="text-slate-900 text-3xl">±4.2</p>
          <p className="text-sm text-blue-600 mt-2">Low variance</p>
        </div>
        <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200">
          <p className="text-sm text-slate-500 mb-2">Hypotensive Events</p>
          <p className="text-slate-900 text-3xl">2</p>
          <p className="text-sm text-orange-600 mt-2">Last: 4h ago</p>
        </div>
      </div>
    </div>
  );
}
