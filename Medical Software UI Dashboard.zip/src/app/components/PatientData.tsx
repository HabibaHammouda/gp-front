import { User, Calendar, Weight, Ruler } from 'lucide-react';

export function PatientData() {
  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-200">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
          <User size={20} className="text-white" />
        </div>
        <div>
          <h3 className="text-slate-900">Patient Information</h3>
          <p className="text-sm text-slate-500">ICU Bed 203</p>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-6">
        {/* Demographics */}
        <div className="space-y-4">
          <h4 className="text-slate-700">Demographics</h4>
          <div className="space-y-3">
            <div>
              <p className="text-xs text-slate-500">Patient ID</p>
              <p className="text-slate-900">ICU-2024-0847</p>
            </div>
            <div>
              <p className="text-xs text-slate-500">Age / Sex</p>
              <p className="text-slate-900">67 years / M</p>
            </div>
            <div className="flex items-center gap-2">
              <Calendar size={14} className="text-slate-400" />
              <div>
                <p className="text-xs text-slate-500">Admission</p>
                <p className="text-slate-900 text-sm">Nov 24, 2025</p>
              </div>
            </div>
          </div>
        </div>

        {/* Vitals */}
        <div className="space-y-4">
          <h4 className="text-slate-700">Physical</h4>
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Weight size={14} className="text-slate-400" />
              <div>
                <p className="text-xs text-slate-500">Weight</p>
                <p className="text-slate-900">82 kg</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Ruler size={14} className="text-slate-400" />
              <div>
                <p className="text-xs text-slate-500">Height</p>
                <p className="text-slate-900">175 cm</p>
              </div>
            </div>
            <div>
              <p className="text-xs text-slate-500">BMI</p>
              <p className="text-slate-900">26.8</p>
            </div>
          </div>
        </div>

        {/* Diagnosis */}
        <div className="space-y-4">
          <h4 className="text-slate-700">Primary Diagnosis</h4>
          <div className="space-y-3">
            <div className="px-3 py-2 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-xs text-red-700">Septic Shock</p>
            </div>
            <div className="px-3 py-2 bg-orange-50 border border-orange-200 rounded-lg">
              <p className="text-xs text-orange-700">Pneumonia</p>
            </div>
            <div className="px-3 py-2 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-xs text-yellow-700">Acute Kidney Injury</p>
            </div>
          </div>
        </div>

        {/* Medications */}
        <div className="space-y-4">
          <h4 className="text-slate-700">Active Medications</h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600">Norepinephrine</span>
              <span className="text-slate-900">8.5 μg/min</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Propofol</span>
              <span className="text-slate-900">25 mg/h</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Fentanyl</span>
              <span className="text-slate-900">50 μg/h</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">Piperacillin</span>
              <span className="text-slate-900">4.5g q6h</span>
            </div>
          </div>
        </div>
      </div>

      {/* Lab Values */}
      <div className="mt-6 pt-6 border-t border-slate-200">
        <h4 className="text-slate-700 mb-4">Recent Lab Values</h4>
        <div className="grid grid-cols-6 gap-4 text-sm">
          <div className="px-3 py-2 bg-slate-50 rounded-lg">
            <p className="text-xs text-slate-500">Lactate</p>
            <p className="text-slate-900">2.8 mmol/L</p>
          </div>
          <div className="px-3 py-2 bg-slate-50 rounded-lg">
            <p className="text-xs text-slate-500">ScvO₂</p>
            <p className="text-slate-900">68%</p>
          </div>
          <div className="px-3 py-2 bg-slate-50 rounded-lg">
            <p className="text-xs text-slate-500">Hgb</p>
            <p className="text-slate-900">9.2 g/dL</p>
          </div>
          <div className="px-3 py-2 bg-slate-50 rounded-lg">
            <p className="text-xs text-slate-500">Platelets</p>
            <p className="text-slate-900">142 K/μL</p>
          </div>
          <div className="px-3 py-2 bg-slate-50 rounded-lg">
            <p className="text-xs text-slate-500">Creatinine</p>
            <p className="text-slate-900">1.9 mg/dL</p>
          </div>
          <div className="px-3 py-2 bg-slate-50 rounded-lg">
            <p className="text-xs text-slate-500">WBC</p>
            <p className="text-slate-900">14.2 K/μL</p>
          </div>
        </div>
      </div>
    </div>
  );
}
