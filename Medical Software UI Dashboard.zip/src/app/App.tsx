import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { PatientData } from './components/PatientData';
import { MAPTrends } from './components/MAPTrends';
import { ControllerSettings } from './components/ControllerSettings';
import { SafetyAlerts } from './components/SafetyAlerts';
import { BloodPressureWaveform } from './components/BloodPressureWaveform';
import { VitalCards } from './components/VitalCards';
import { InfusionControl } from './components/InfusionControl';

export type NavigationTab = 'patient-data' | 'map-trends' | 'controller-settings' | 'safety-alerts';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('patient-data');

  return (
    <div className="flex h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-8 py-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-slate-900">ICU Digital-Twin Blood Pressure Control</h1>
              <p className="text-slate-500 text-sm mt-1">Real-time Hemodynamic Monitoring & Control System</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm text-slate-600">System Active</span>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-auto p-6">
          {activeTab === 'patient-data' && (
            <div className="space-y-6">
              {/* Vital Signs Cards */}
              <VitalCards />
              
              {/* Blood Pressure Waveform and Infusion Control */}
              <div className="grid grid-cols-3 gap-6">
                <div className="col-span-2">
                  <BloodPressureWaveform />
                </div>
                <div>
                  <InfusionControl />
                </div>
              </div>

              {/* Patient Details */}
              <PatientData />
            </div>
          )}

          {activeTab === 'map-trends' && <MAPTrends />}
          {activeTab === 'controller-settings' && <ControllerSettings />}
          {activeTab === 'safety-alerts' && <SafetyAlerts />}
        </main>
      </div>
    </div>
  );
}
